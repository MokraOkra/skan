export interface ChangeAvatarRequest {
    userId: number,
    avatar: string
}