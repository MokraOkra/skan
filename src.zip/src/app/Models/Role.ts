export enum Role {
    User = 0,
    Doctor = 1,
    Admin = 2,
}