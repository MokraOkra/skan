export interface ChangePasswordRequest {
    userId: number,
    password: string
}