export interface RegisterRequest {
    username: string,
    password: string,
    name: string,
    surname: string,
    email: string
}