export interface ChangeExperienceRequest {
    userId: number,
    expierience: string
}