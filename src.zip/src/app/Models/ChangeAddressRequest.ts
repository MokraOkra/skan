export interface ChangeAddressRequest {
    userId: number,
    city: string,
    street: string,
    buildingNumber: number
}